# coding=utf-8

from random import shuffle
from datetime import datetime
import pygame
from pygame.locals import Rect

from player.Player import Player
from config import FRAMERATE
from config import ABORT_KEY
from config import EXIT_SUCCESS_CODE, EXIT_ABORT_CODE

import vlc
import wx
import time


class VideoPresentationPlayer(Player, wx.Frame):
    """
    Plays a Video presentation activity and listen for keyboard events
    @param random: If is set to "Yes" tags will be played in a random way. It can be set to "Yes" or "No"
    @type random: str
    @param tags: list of VideoPresentationTag objects that contain all tag info.
    @type tags: list
    """

    def __init__(self, random, tags):
        wx.Frame.__init__(self, None, -1, "Video Player",
                          pos=(0, 0), size=(550, 500))

        self.video_panel = wx.Panel(self, -1)
        self.video_panel.SetBackgroundColour(wx.BLACK)
        self.Instance = vlc.Instance("--no-xlib")
        self.player = self.Instance.media_player_new()

        self.random = random
        self.tags = tags
        if self.random == "Yes":
            shuffle(self.tags)
        self.done = False
        self.return_code = EXIT_SUCCESS_CODE
        self.event_thread = None

        self.zerotime = None
        self.media = None

    def play(self, writer):
        """
        Plays activity tags.
        @param writer: Object that write tags info.
        """

        self.zerotime = datetime.now()

        for tag in self.tags:

            self.media = self.Instance.media_new(tag.path)
            self.player.set_media(self.media)
            self.player.set_xwindow(self.video_panel.GetHandle())
            beg = (datetime.now() - self.zerotime).total_seconds()
            self.player.play()

            while self.player.get_length() >= self.player.get_time() and not self.done:
                print self.player.get_length()
                print self.player.get_time()
                # for event in pygame.event.get(pygame.KEYDOWN):
                #     if event.key == ABORT_KEY:
                #         self.player.stop()
                #         self.done = True
                time.sleep(0.001)



            if self.done:
                self.stop()
                self.return_code = EXIT_ABORT_CODE
                break

            end = (datetime.now() - self.zerotime).total_seconds()
            writer.write_tag_value(tag.name, beg, end)

        self.stop()
        self.raise_if_needed(self.return_code)

    def stop(self):
        self.done = True


